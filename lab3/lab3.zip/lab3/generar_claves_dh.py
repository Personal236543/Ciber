from cryptography.hazmat.primitives.asymmetric import dh
from cryptography.hazmat.primitives import serialization

with open("dh_parametros.pem", "rb") as f:
    parameters = serialization.load_pem_parameters(f.read())

private_key = parameters.generate_private_key()
public_key = private_key.public_key()

priv_pem = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption()
)
with open("dh_privada.pem", "wb") as f:
    f.write(priv_pem)

pub_pem = public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)
with open("dh_publica.pem", "wb") as f:
    f.write(pub_pem)

print("[OK] dh_privada.pem (NO compartir) y dh_publica.pem (SI compartir) generados")