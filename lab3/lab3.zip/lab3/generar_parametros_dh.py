from cryptography.hazmat.primitives.asymmetric import dh
from cryptography.hazmat.primitives import serialization

parameters = dh.generate_parameters(generator=2, key_size=2048)

pem = parameters.parameter_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.ParameterFormat.PKCS3
)

with open("dh_parametros.pem", "wb") as f:
    f.write(pem)

print("[OK] Parámetros DH generados en dh_parametros.pem")