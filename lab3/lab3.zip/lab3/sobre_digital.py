#!/usr/bin/env python3
"""
sobre_digital.py
Lab 3 - Cifrado Asimetrico y Distribucion de Claves
Genera una clave simetrica AES aleatoria y la cifra con RSA usando la
clave publica del destinatario. Tambien permite descifrarla con la
clave privada del destinatario.

Uso:
    # En el REMITENTE (genera una clave AES nueva y la cifra con RSA)
    python3 sobre_digital.py generar_y_cifrar <clave_publica_destinatario.pem> <clave_aes_cifrada.bin> <clave_aes_texto_plano.key>

    # En el DESTINATARIO (descifra la clave AES con su clave privada)
    python3 sobre_digital.py descifrar_clave <clave_privada_propia.pem> <clave_aes_cifrada.bin> <clave_aes_recuperada.key>
"""

import sys
import os
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Random import get_random_bytes


def generar_y_cifrar(ruta_pub_destinatario: str, ruta_salida_cifrada: str, ruta_salida_clave_plana: str):
    # 1. Generar una clave AES-256 aleatoria (32 bytes)
    clave_aes = get_random_bytes(32)

    # Guardamos la clave AES en texto plano (LOCAL, para usarla con cifrado_ftp.py)
    # En un caso real, este archivo se borraria despues de usarlo.
    with open(ruta_salida_clave_plana, "wb") as f:
        f.write(clave_aes)
    print(f"[OK] Clave AES generada y guardada temporalmente en: {ruta_salida_clave_plana}")
    print(f"     (Esta clave en texto plano es SOLO para uso local del remitente)")

    # 2. Cargar la clave publica del destinatario
    with open(ruta_pub_destinatario, "rb") as f:
        clave_publica = RSA.import_key(f.read())

    # 3. Cifrar la clave AES usando RSA (PKCS1_OAEP es el esquema recomendado)
    cifrador_rsa = PKCS1_OAEP.new(clave_publica)
    clave_aes_cifrada = cifrador_rsa.encrypt(clave_aes)

    with open(ruta_salida_cifrada, "wb") as f:
        f.write(clave_aes_cifrada)

    print(f"[OK] Clave AES cifrada con RSA guardada en: {ruta_salida_cifrada}")
    print(f"     Tamano de la clave AES cifrada: {len(clave_aes_cifrada)} bytes")


def descifrar_clave(ruta_priv_propia: str, ruta_entrada_cifrada: str, ruta_salida_clave: str):
    # 1. Cargar la clave privada propia
    with open(ruta_priv_propia, "rb") as f:
        clave_privada = RSA.import_key(f.read())

    # 2. Leer la clave AES cifrada
    with open(ruta_entrada_cifrada, "rb") as f:
        clave_aes_cifrada = f.read()

    # 3. Descifrar usando RSA + la clave privada
    descifrador_rsa = PKCS1_OAEP.new(clave_privada)
    clave_aes = descifrador_rsa.decrypt(clave_aes_cifrada)

    with open(ruta_salida_clave, "wb") as f:
        f.write(clave_aes)

    print(f"[OK] Clave AES descifrada y guardada en: {ruta_salida_clave}")


def main():
    if len(sys.argv) != 5:
        print(__doc__)
        sys.exit(1)

    modo = sys.argv[1]

    if modo == "generar_y_cifrar":
        _, _, ruta_pub, ruta_salida_cifrada, ruta_salida_clave_plana = sys.argv
        if not os.path.isfile(ruta_pub):
            print(f"[ERROR] No existe: {ruta_pub}")
            sys.exit(1)
        generar_y_cifrar(ruta_pub, ruta_salida_cifrada, ruta_salida_clave_plana)

    elif modo == "descifrar_clave":
        _, _, ruta_priv, ruta_entrada_cifrada, ruta_salida_clave = sys.argv
        if not os.path.isfile(ruta_priv) or not os.path.isfile(ruta_entrada_cifrada):
            print("[ERROR] Alguno de los archivos de entrada no existe.")
            sys.exit(1)
        descifrar_clave(ruta_priv, ruta_entrada_cifrada, ruta_salida_clave)

    else:
        print("[ERROR] Modo no reconocido. Use 'generar_y_cifrar' o 'descifrar_clave'.")
        sys.exit(1)


if __name__ == "__main__":
    main()