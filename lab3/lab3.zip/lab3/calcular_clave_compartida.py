import sys
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

peer_pub_file = sys.argv[1]

with open("dh_privada.pem", "rb") as f:
    private_key = serialization.load_pem_private_key(f.read(), password=None)

with open(peer_pub_file, "rb") as f:
    peer_public_key = serialization.load_pem_public_key(f.read())

shared_secret = private_key.exchange(peer_public_key)

derived_key = HKDF(
    algorithm=hashes.SHA256(),
    length=32,
    salt=None,
    info=b"canal-dh-student1-student2"
).derive(shared_secret)

with open("clave_aes_dh.key", "wb") as f:
    f.write(derived_key)

print("[OK] Clave compartida derivada en clave_aes_dh.key")